import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    
    if (!session?.user?.id) {
      return Response.json({ error: 'User not authenticated' }, { status: 401 });
    }

    // Get user profile first
    const userProfile = await sql`
      SELECT id, company_id, role FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json({ error: 'User profile not found' }, { status: 404 });
    }

    const profile = userProfile[0];
    const url = new URL(request.url);
    const status = url.searchParams.get('status');
    const limit = parseInt(url.searchParams.get('limit')) || 50;
    const offset = parseInt(url.searchParams.get('offset')) || 0;

    let expensesQuery;

    if (profile.role === 'employee') {
      // Employees can only see their own expenses
      expensesQuery = `
        SELECT 
          e.*,
          ec.name as category_name,
          u.name as employee_name,
          u.email as employee_email
        FROM expenses e
        LEFT JOIN expense_categories ec ON e.category_id = ec.id
        JOIN user_profiles up ON e.employee_id = up.id
        JOIN auth_users u ON up.user_id = u.id
        WHERE e.employee_id = $1
        ${status ? 'AND e.status = $2' : ''}
        ORDER BY e.created_at DESC
        LIMIT $${status ? 3 : 2} OFFSET $${status ? 4 : 3}
      `;
    } else {
      // Managers and admins can see all expenses in their company
      expensesQuery = `
        SELECT 
          e.*,
          ec.name as category_name,
          u.name as employee_name,
          u.email as employee_email
        FROM expenses e
        LEFT JOIN expense_categories ec ON e.category_id = ec.id
        JOIN user_profiles up ON e.employee_id = up.id
        JOIN auth_users u ON up.user_id = u.id
        WHERE e.company_id = $1
        ${status ? 'AND e.status = $2' : ''}
        ORDER BY e.created_at DESC
        LIMIT $${status ? 3 : 2} OFFSET $${status ? 4 : 3}
      `;
    }

    const params = profile.role === 'employee' 
      ? [profile.id, ...(status ? [status] : []), limit, offset]
      : [profile.company_id, ...(status ? [status] : []), limit, offset];

    const expenses = await sql(expensesQuery, params);

    return Response.json({ expenses });

  } catch (error) {
    console.error('Get expenses error:', error);
    return Response.json(
      { error: 'Failed to get expenses' }, 
      { status: 500 }
    );
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    
    if (!session?.user?.id) {
      return Response.json({ error: 'User not authenticated' }, { status: 401 });
    }

    // Get user profile
    const userProfile = await sql`
      SELECT id, company_id, role FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json({ error: 'User profile not found' }, { status: 404 });
    }

    const profile = userProfile[0];
    const body = await request.json();
    const { amount, currency, description, expense_date, category_id, receipt_url } = body;

    if (!amount || !currency || !description || !expense_date) {
      return Response.json({ 
        error: 'Amount, currency, description, and expense date are required' 
      }, { status: 400 });
    }

    // Create expense
    const expenseResult = await sql`
      INSERT INTO expenses (
        company_id, employee_id, category_id, amount, currency, 
        description, expense_date, receipt_url, status
      )
      VALUES (
        ${profile.company_id}, ${profile.id}, ${category_id}, ${amount}, 
        ${currency}, ${description}, ${expense_date}, ${receipt_url}, 'pending'
      )
      RETURNING *
    `;

    const expense = expenseResult[0];

    // Add to approval history
    await sql`
      INSERT INTO approval_history (expense_id, action, new_status)
      VALUES (${expense.id}, 'submitted', 'pending')
    `;

    // TODO: Create approval workflow based on company rules
    // For now, we'll create a simple workflow that requires admin approval

    return Response.json({ 
      success: true, 
      expense,
      message: 'Expense submitted successfully' 
    });

  } catch (error) {
    console.error('Create expense error:', error);
    return Response.json(
      { error: 'Failed to create expense' }, 
      { status: 500 }
    );
  }
}
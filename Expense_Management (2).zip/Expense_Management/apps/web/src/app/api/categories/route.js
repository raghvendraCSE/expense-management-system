import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    
    if (!session?.user?.id) {
      return Response.json({ error: 'User not authenticated' }, { status: 401 });
    }

    // Get user profile to find company
    const userProfile = await sql`
      SELECT company_id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json({ error: 'User profile not found' }, { status: 404 });
    }

    const companyId = userProfile[0].company_id;

    // Get categories for the company
    const categories = await sql`
      SELECT id, name, description, is_active
      FROM expense_categories 
      WHERE company_id = ${companyId} AND is_active = true
      ORDER BY name
    `;

    return Response.json({ categories });

  } catch (error) {
    console.error('Get categories error:', error);
    return Response.json(
      { error: 'Failed to get categories' }, 
      { status: 500 }
    );
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    
    if (!session?.user?.id) {
      return Response.json({ error: 'User not authenticated' }, { status: 401 });
    }

    // Get user profile and check if admin
    const userProfile = await sql`
      SELECT company_id, role FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (userProfile.length === 0) {
      return Response.json({ error: 'User profile not found' }, { status: 404 });
    }

    const profile = userProfile[0];

    if (profile.role !== 'admin') {
      return Response.json({ error: 'Only admins can create categories' }, { status: 403 });
    }

    const body = await request.json();
    const { name, description } = body;

    if (!name) {
      return Response.json({ error: 'Category name is required' }, { status: 400 });
    }

    // Create category
    const categoryResult = await sql`
      INSERT INTO expense_categories (company_id, name, description)
      VALUES (${profile.company_id}, ${name}, ${description})
      RETURNING *
    `;

    return Response.json({ 
      success: true, 
      category: categoryResult[0],
      message: 'Category created successfully' 
    });

  } catch (error) {
    console.error('Create category error:', error);
    return Response.json(
      { error: 'Failed to create category' }, 
      { status: 500 }
    );
  }
}
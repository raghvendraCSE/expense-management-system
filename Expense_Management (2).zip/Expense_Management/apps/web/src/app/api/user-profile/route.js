import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    
    if (!session?.user?.id) {
      return Response.json({ error: 'User not authenticated' }, { status: 401 });
    }

    // Get user profile with company information
    const profile = await sql`
      SELECT 
        up.id,
        up.user_id,
        up.company_id,
        up.role,
        up.manager_id,
        up.is_manager_approver,
        c.name as company_name,
        c.country,
        c.currency,
        u.name as user_name,
        u.email,
        mgr_user.name as manager_name
      FROM user_profiles up
      JOIN companies c ON up.company_id = c.id
      JOIN auth_users u ON up.user_id = u.id
      LEFT JOIN user_profiles mgr ON up.manager_id = mgr.id
      LEFT JOIN auth_users mgr_user ON mgr.user_id = mgr_user.id
      WHERE up.user_id = ${session.user.id}
    `;

    if (profile.length === 0) {
      return Response.json({ error: 'User profile not found' }, { status: 404 });
    }

    return Response.json(profile[0]);

  } catch (error) {
    console.error('Get profile error:', error);
    return Response.json(
      { error: 'Failed to get user profile' }, 
      { status: 500 }
    );
  }
}
import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

// Currency mapping for countries
const currencyMap = {
  'US': 'USD',
  'CA': 'CAD', 
  'GB': 'GBP',
  'DE': 'EUR',
  'FR': 'EUR',
  'AU': 'AUD',
  'JP': 'JPY',
  'IN': 'INR'
};

export async function POST(request) {
  try {
    const session = await auth();
    
    if (!session?.user?.id) {
      return Response.json({ error: 'User not authenticated' }, { status: 401 });
    }

    const body = await request.json();
    const { companyName, country } = body;

    if (!companyName || !country) {
      return Response.json({ error: 'Company name and country are required' }, { status: 400 });
    }

    const currency = currencyMap[country] || 'USD';

    // Check if user already has a company
    const existingProfile = await sql`
      SELECT id FROM user_profiles WHERE user_id = ${session.user.id}
    `;

    if (existingProfile.length > 0) {
      return Response.json({ error: 'User already has a company setup' }, { status: 400 });
    }

    // Create company and user profile in a transaction
    const result = await sql.transaction([
      // Create company
      sql`
        INSERT INTO companies (name, country, currency)
        VALUES (${companyName}, ${country}, ${currency})
        RETURNING id
      `,
      // Create admin user profile (will be done after getting company id)
    ]);

    const [companyResult] = result;
    const companyId = companyResult[0].id;

    // Create admin user profile
    await sql`
      INSERT INTO user_profiles (user_id, company_id, role, is_manager_approver)
      VALUES (${session.user.id}, ${companyId}, 'admin', true)
    `;

    // Create default expense categories for the company
    await sql`
      INSERT INTO expense_categories (company_id, name, description) VALUES
      (${companyId}, 'Travel', 'Business travel expenses'),
      (${companyId}, 'Meals', 'Business meal expenses'),
      (${companyId}, 'Office Supplies', 'Office supplies and equipment'),
      (${companyId}, 'Training', 'Training and education expenses'),
      (${companyId}, 'Entertainment', 'Business entertainment expenses')
    `;

    // Create a default approval rule for the company
    const defaultRule = {
      approvers: [{ role: 'admin', required: true }],
      conditions: { sequential: true }
    };

    await sql`
      INSERT INTO approval_rules (company_id, name, rule_type, rule_config)
      VALUES (${companyId}, 'Default Admin Approval', 'sequential', ${JSON.stringify(defaultRule)})
    `;

    return Response.json({ 
      success: true, 
      companyId,
      message: 'Company setup completed successfully' 
    });

  } catch (error) {
    console.error('Signup error:', error);
    return Response.json(
      { error: 'Failed to setup company' }, 
      { status: 500 }
    );
  }
}
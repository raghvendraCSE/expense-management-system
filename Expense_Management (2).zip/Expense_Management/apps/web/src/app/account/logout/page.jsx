import useAuth from "@/utils/useAuth";

export default function LogoutPage() {
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut({
      callbackUrl: "/",
      redirect: true,
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#121212] flex items-center justify-center">
      <div className="max-w-md w-full bg-white dark:bg-[#1E1E1E] rounded-lg shadow-sm border border-gray-200 dark:border-gray-800 p-8">
        <div className="text-center">
          <div className="flex items-center justify-center mb-8">
            <div className="w-8 h-8 bg-[#18B84E] dark:bg-[#16A249] rounded flex items-center justify-center">
              <span className="text-white font-bold text-sm">EM</span>
            </div>
            <div className="ml-2 flex items-center">
              <span className="text-[#111111] dark:text-white font-medium text-lg">
                Expense
              </span>
              <span className="text-[#18B84E] dark:text-[#16A249] font-medium text-lg">
                Manager
              </span>
            </div>
          </div>

          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Sign Out
          </h2>
          <p className="text-gray-600 dark:text-gray-400 mb-8">
            Are you sure you want to sign out of your account?
          </p>

          <button
            onClick={handleSignOut}
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-[#18B84E] hover:bg-[#16A249] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#18B84E]"
          >
            Sign Out
          </button>

          <div className="mt-6">
            <a
              href="/dashboard"
              className="text-sm text-[#18B84E] hover:text-[#16A249] font-medium"
            >
              Cancel and go back to dashboard
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
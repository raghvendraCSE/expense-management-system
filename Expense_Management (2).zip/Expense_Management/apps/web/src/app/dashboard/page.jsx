import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import useUser from "@/utils/useUser";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import ExpenseForm from "@/components/ExpenseForm";
import ExpensesList from "@/components/ExpensesList";
import Dashboard from "@/components/Dashboard";

export default function DashboardPage() {
  const { data: user, loading } = useUser();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [currentTab, setCurrentTab] = useState("dashboard");
  const [showExpenseForm, setShowExpenseForm] = useState(false);
  const [userProfile, setUserProfile] = useState(null);

  useEffect(() => {
    if (user?.id) {
      fetch("/api/user-profile")
        .then((res) => res.json())
        .then((data) => {
          if (!data.error) {
            setUserProfile(data);
          }
        })
        .catch(console.error);
    }
  }, [user]);

  // Redirect to signin if not authenticated
  useEffect(() => {
    if (!loading && !user) {
      window.location.href = "/account/signin?callbackUrl=/dashboard";
    }
  }, [user, loading]);

  // Check if user needs to complete company setup
  useEffect(() => {
    if (user && !loading) {
      fetch("/api/user-profile")
        .then((res) => res.json())
        .then((data) => {
          if (data.error && data.error.includes("not found")) {
            // User needs to complete company setup
            window.location.href = "/account/signup";
          }
        })
        .catch(console.error);
    }
  }, [user, loading]);

  const handleTabChange = (tab) => {
    setCurrentTab(tab);
    setSidebarOpen(false);
  };

  const handleNewExpense = () => {
    setShowExpenseForm(true);
  };

  const handleExpenseSubmitted = () => {
    // Could refresh data here if needed
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-[#121212] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-[#18B84E]"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const renderContent = () => {
    switch (currentTab) {
      case "expenses":
        return <ExpensesList />;
      case "approvals":
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Approvals
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              Approval workflow features coming soon...
            </p>
          </div>
        );
      case "reports":
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Reports
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              Reporting features coming soon...
            </p>
          </div>
        );
      case "users":
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Team Management
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              User management features coming soon...
            </p>
          </div>
        );
      case "settings":
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Settings
            </h2>
            <p className="text-gray-600 dark:text-gray-400">
              Settings features coming soon...
            </p>
          </div>
        );
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#121212] flex">
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 dark:bg-opacity-70 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div
        className={`
        fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-[#1E1E1E] border-r border-gray-200 dark:border-gray-800 transform transition-transform duration-300 ease-in-out
        ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}
        lg:translate-x-0 lg:relative lg:flex-shrink-0
      `}
      >
        <Sidebar
          onClose={() => setSidebarOpen(false)}
          currentTab={currentTab}
          onTabChange={handleTabChange}
        />
      </div>

      {/* Main content area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Mobile menu button */}
        <div className="lg:hidden">
          <div className="flex items-center justify-between p-4 bg-white dark:bg-[#1E1E1E] border-b border-gray-200 dark:border-gray-800">
            <button
              onClick={() => setSidebarOpen(true)}
              className="p-2 rounded-md text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-150"
            >
              <Menu className="h-6 w-6" />
            </button>
            {/* Mobile logo */}
            <div className="flex items-center">
              <div className="w-8 h-8 bg-[#18B84E] dark:bg-[#16A249] rounded flex items-center justify-center">
                <span className="text-white font-bold text-sm">EM</span>
              </div>
              <div className="ml-2 flex items-center">
                <span className="text-[#111111] dark:text-white font-medium text-lg">
                  Expense
                </span>
                <span className="text-[#18B84E] dark:text-[#16A249] font-medium text-lg">
                  Manager
                </span>
              </div>
            </div>
            <div className="w-10" />
          </div>
        </div>

        {/* Header - Desktop only */}
        <div className="hidden lg:block flex-shrink-0 sticky top-0 z-30">
          <Header
            currentTab={currentTab}
            onTabChange={handleTabChange}
            onNewExpense={handleNewExpense}
          />
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto">{renderContent()}</div>
      </div>

      {/* Expense Form Modal */}
      <ExpenseForm
        isOpen={showExpenseForm}
        onClose={() => setShowExpenseForm(false)}
        onSubmit={handleExpenseSubmitted}
      />
    </div>
  );
}

import { useState, useEffect } from "react";
import { TrendingUp, TrendingDown, Receipt, Clock, CheckCircle, Users } from "lucide-react";
import useUser from "@/utils/useUser";

const StatCard = ({ title, value, change, changeType, icon: Icon, color = "green" }) => {
  const colors = {
    green: "text-green-600 dark:text-green-400",
    blue: "text-blue-600 dark:text-blue-400",
    yellow: "text-yellow-600 dark:text-yellow-400",
    red: "text-red-600 dark:text-red-400"
  };

  const bgColors = {
    green: "bg-green-50 dark:bg-green-900/20",
    blue: "bg-blue-50 dark:bg-blue-900/20", 
    yellow: "bg-yellow-50 dark:bg-yellow-900/20",
    red: "bg-red-50 dark:bg-red-900/20"
  };

  return (
    <div className="bg-white dark:bg-[#1E1E1E] rounded-lg border border-gray-200 dark:border-gray-800 p-6">
      <div className="flex items-center">
        <div className={`p-3 rounded-lg ${bgColors[color]}`}>
          <Icon className={`h-6 w-6 ${colors[color]}`} />
        </div>
        <div className="ml-4 flex-1">
          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{title}</p>
          <div className="flex items-baseline">
            <p className="text-2xl font-semibold text-gray-900 dark:text-white">{value}</p>
            {change && (
              <p className={`ml-2 flex items-baseline text-sm font-semibold ${
                changeType === 'increase' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
              }`}>
                {changeType === 'increase' ? (
                  <TrendingUp className="h-4 w-4 mr-1" />
                ) : (
                  <TrendingDown className="h-4 w-4 mr-1" />
                )}
                {change}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

const RecentExpensesList = ({ expenses }) => {
  if (!expenses || expenses.length === 0) {
    return (
      <div className="text-center py-8">
        <Receipt className="h-12 w-12 text-gray-400 dark:text-gray-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No expenses yet</h3>
        <p className="text-gray-500 dark:text-gray-400">Your recent expenses will appear here.</p>
      </div>
    );
  }

  return (
    <div className="flow-root">
      <ul className="-mb-8">
        {expenses.slice(0, 5).map((expense, expenseIdx) => (
          <li key={expense.id}>
            <div className="relative pb-8">
              {expenseIdx !== expenses.length - 1 && expenseIdx !== 4 ? (
                <span
                  className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200 dark:bg-gray-700"
                  aria-hidden="true"
                />
              ) : null}
              <div className="relative flex space-x-3">
                <div>
                  <span className={`h-8 w-8 rounded-full flex items-center justify-center ring-8 ring-white dark:ring-[#1E1E1E] ${
                    expense.status === 'approved' 
                      ? 'bg-green-500' 
                      : expense.status === 'rejected'
                      ? 'bg-red-500'
                      : 'bg-yellow-500'
                  }`}>
                    {expense.status === 'approved' ? (
                      <CheckCircle className="h-5 w-5 text-white" />
                    ) : expense.status === 'rejected' ? (
                      <Clock className="h-5 w-5 text-white" />
                    ) : (
                      <Clock className="h-5 w-5 text-white" />
                    )}
                  </span>
                </div>
                <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                  <div>
                    <p className="text-sm text-gray-900 dark:text-white font-medium truncate">
                      {expense.description}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {expense.category_name || 'Uncategorized'} • {expense.employee_name}
                    </p>
                  </div>
                  <div className="text-right text-sm whitespace-nowrap">
                    <p className="font-medium text-gray-900 dark:text-white">
                      {expense.currency} {parseFloat(expense.amount).toFixed(2)}
                    </p>
                    <p className="text-gray-500 dark:text-gray-400">
                      {new Date(expense.expense_date).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default function Dashboard() {
  const { data: user } = useUser();
  const [dashboardData, setDashboardData] = useState({
    stats: {
      totalExpenses: 0,
      pendingExpenses: 0,
      approvedExpenses: 0,
      totalAmount: 0
    },
    recentExpenses: [],
    loading: true,
    error: null
  });
  const [userProfile, setUserProfile] = useState(null);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setDashboardData(prev => ({ ...prev, loading: true }));
        
        // Load user profile
        const profileResponse = await fetch('/api/user-profile');
        const profileData = await profileResponse.json();
        if (!profileResponse.ok) {
          throw new Error(profileData.error || 'Failed to load profile');
        }
        setUserProfile(profileData);

        // Load expenses
        const expensesResponse = await fetch('/api/expenses?limit=10');
        const expensesData = await expensesResponse.json();
        
        if (!expensesResponse.ok) {
          throw new Error(expensesData.error || 'Failed to load expenses');
        }

        const expenses = expensesData.expenses || [];
        
        // Calculate stats
        const stats = {
          totalExpenses: expenses.length,
          pendingExpenses: expenses.filter(e => e.status === 'pending').length,
          approvedExpenses: expenses.filter(e => e.status === 'approved').length,
          totalAmount: expenses.reduce((sum, expense) => sum + parseFloat(expense.amount), 0)
        };

        setDashboardData({
          stats,
          recentExpenses: expenses,
          loading: false,
          error: null
        });

      } catch (error) {
        setDashboardData(prev => ({
          ...prev,
          loading: false,
          error: error.message
        }));
      }
    };

    if (user?.id) {
      loadDashboardData();
    }
  }, [user]);

  const { stats, recentExpenses, loading, error } = dashboardData;

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 dark:bg-gray-700 rounded"></div>
            ))}
          </div>
          <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-lg p-4">
          <h3 className="text-lg font-semibold text-red-800 dark:text-red-200">Error</h3>
          <p className="text-red-600 dark:text-red-300">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Welcome back{userProfile?.user_name ? `, ${userProfile.user_name}` : ''}!
        </h1>
        <p className="mt-1 text-gray-600 dark:text-gray-400">
          Here's what's happening with your expenses today.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          title="Total Expenses"
          value={stats.totalExpenses}
          icon={Receipt}
          color="blue"
        />
        <StatCard
          title="Pending Approval"
          value={stats.pendingExpenses}
          icon={Clock}
          color="yellow"
        />
        <StatCard
          title="Approved"
          value={stats.approvedExpenses}
          icon={CheckCircle}
          color="green"
        />
        <StatCard
          title="Total Amount"
          value={`$${stats.totalAmount.toFixed(2)}`}
          icon={TrendingUp}
          color="green"
        />
      </div>

      {/* Recent Expenses */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-[#1E1E1E] rounded-lg border border-gray-200 dark:border-gray-800 p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Recent Expenses
            </h3>
            <button className="text-sm text-[#18B84E] hover:text-[#16A249] font-medium">
              View all
            </button>
          </div>
          <RecentExpensesList expenses={recentExpenses} />
        </div>

        {/* Quick Actions */}
        <div className="bg-white dark:bg-[#1E1E1E] rounded-lg border border-gray-200 dark:border-gray-800 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-6">
            Quick Actions
          </h3>
          <div className="space-y-4">
            {userProfile?.role !== 'admin' && (
              <button className="w-full text-left p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors duration-150">
                <div className="flex items-center">
                  <Receipt className="h-5 w-5 text-[#18B84E] mr-3" />
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 dark:text-white">
                      Submit New Expense
                    </h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Add a new expense for approval
                    </p>
                  </div>
                </div>
              </button>
            )}
            
            <button className="w-full text-left p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors duration-150">
              <div className="flex items-center">
                <CheckCircle className="h-5 w-5 text-blue-600 mr-3" />
                <div>
                  <h4 className="text-sm font-medium text-gray-900 dark:text-white">
                    View Expense History
                  </h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Review your submitted expenses
                  </p>
                </div>
              </div>
            </button>

            {(userProfile?.role === 'admin' || userProfile?.role === 'manager') && (
              <button className="w-full text-left p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors duration-150">
                <div className="flex items-center">
                  <Users className="h-5 w-5 text-purple-600 mr-3" />
                  <div>
                    <h4 className="text-sm font-medium text-gray-900 dark:text-white">
                      Review Approvals
                    </h4>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Approve or reject pending expenses
                    </p>
                  </div>
                </div>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Company Info */}
      {userProfile && (
        <div className="bg-white dark:bg-[#1E1E1E] rounded-lg border border-gray-200 dark:border-gray-800 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Company Information
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Company</p>
              <p className="text-sm text-gray-900 dark:text-white">{userProfile.company_name}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Your Role</p>
              <p className="text-sm text-gray-900 dark:text-white capitalize">{userProfile.role}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Currency</p>
              <p className="text-sm text-gray-900 dark:text-white">{userProfile.currency}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
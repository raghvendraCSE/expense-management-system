import { useState, useEffect } from "react";
import {
  Search,
  Filter,
  Download,
  ArrowUpDown,
  Receipt,
  Clock,
  CheckCircle,
  XCircle,
  FileText,
  AlertCircle,
} from "lucide-react";

const StatusBadge = ({ status }) => {
  const styles = {
    pending: "bg-yellow-50 text-yellow-800 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-300 dark:border-yellow-700",
    approved: "bg-green-50 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-300 dark:border-green-700",
    rejected: "bg-red-50 text-red-800 border-red-200 dark:bg-red-900/20 dark:text-red-300 dark:border-red-700",
    processing: "bg-blue-50 text-blue-800 border-blue-200 dark:bg-blue-900/20 dark:text-blue-300 dark:border-blue-700"
  };

  const icons = {
    pending: Clock,
    approved: CheckCircle,
    rejected: XCircle,
    processing: AlertCircle
  };

  const Icon = icons[status] || Clock;

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${styles[status] || styles.pending}`}>
      <Icon className="w-3 h-3 mr-1" />
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
};

const ExpensesTable = ({ expenses, onRowClick }) => {
  const [sortConfig, setSortConfig] = useState({ key: null, direction: "asc" });

  const handleSort = (key) => {
    let direction = "asc";
    if (sortConfig.key === key && sortConfig.direction === "asc") {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };

  const sortedExpenses = [...expenses].sort((a, b) => {
    if (!sortConfig.key) return 0;

    let aValue = a[sortConfig.key];
    let bValue = b[sortConfig.key];

    if (sortConfig.key === "amount") {
      aValue = parseFloat(aValue);
      bValue = parseFloat(bValue);
    }

    if (aValue < bValue) {
      return sortConfig.direction === "asc" ? -1 : 1;
    }
    if (aValue > bValue) {
      return sortConfig.direction === "asc" ? 1 : -1;
    }
    return 0;
  });

  const HeaderCell = ({ children, sortKey, className = "" }) => (
    <th
      className={`px-4 lg:px-6 py-3 text-left text-sm font-semibold text-gray-600 dark:text-gray-300 cursor-pointer hover:text-gray-800 dark:hover:text-gray-100 transition-colors duration-150 ${className}`}
      onClick={() => handleSort(sortKey)}
    >
      <div className="flex items-center gap-2">
        {children}
        <ArrowUpDown className="w-3.5 h-3.5 text-gray-400 dark:text-gray-500" />
      </div>
    </th>
  );

  if (expenses.length === 0) {
    return (
      <div className="bg-white dark:bg-[#1E1E1E] rounded-lg border border-gray-200 dark:border-gray-800 p-12 text-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center">
            <FileText className="w-8 h-8 text-gray-400 dark:text-gray-500" />
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              No expenses found
            </h3>
            <p className="text-gray-500 dark:text-gray-400 max-w-md">
              You don't have any expenses to display yet. Start by submitting your first expense.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-[#1E1E1E] rounded-lg border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[600px]">
          <thead className="bg-gray-50 dark:bg-[#262626]">
            <tr>
              <HeaderCell sortKey="description">Description</HeaderCell>
              <HeaderCell sortKey="category_name">Category</HeaderCell>
              <HeaderCell sortKey="amount" className="text-right">Amount</HeaderCell>
              <HeaderCell sortKey="expense_date">Date</HeaderCell>
              <HeaderCell sortKey="status">Status</HeaderCell>
              <HeaderCell sortKey="employee_name">Employee</HeaderCell>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
            {sortedExpenses.map((expense) => (
              <tr
                key={expense.id}
                className="hover:bg-gray-50 dark:hover:bg-gray-800 active:bg-gray-100 dark:active:bg-gray-700 cursor-pointer transition-colors duration-150"
                onClick={() => onRowClick?.(expense)}
              >
                <td className="px-4 lg:px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                      <Receipt className="w-4 h-4 text-gray-500 dark:text-gray-400" />
                    </div>
                    <div className="min-w-0">
                      <div className="font-medium text-gray-900 dark:text-white truncate">
                        {expense.description}
                      </div>
                      {expense.receipt_url && (
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                          Receipt attached
                        </div>
                      )}
                    </div>
                  </div>
                </td>

                <td className="px-4 lg:px-6 py-4">
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
                    {expense.category_name || 'Uncategorized'}
                  </span>
                </td>

                <td className="px-4 lg:px-6 py-4 text-right">
                  <div className="font-semibold text-gray-900 dark:text-white">
                    {expense.currency} {parseFloat(expense.amount).toFixed(2)}
                  </div>
                </td>

                <td className="px-4 lg:px-6 py-4 text-sm text-gray-900 dark:text-white">
                  {new Date(expense.expense_date).toLocaleDateString()}
                </td>

                <td className="px-4 lg:px-6 py-4">
                  <StatusBadge status={expense.status} />
                </td>

                <td className="px-4 lg:px-6 py-4">
                  <div className="text-sm text-gray-900 dark:text-white">
                    {expense.employee_name || 'Unknown'}
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">
                    {expense.employee_email}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const SummaryCard = ({ expenses }) => {
  if (!expenses || expenses.length === 0) {
    return (
      <div className="bg-white dark:bg-[#1E1E1E] rounded-lg border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="bg-gray-100 dark:bg-[#262626] px-6 py-4 border-b border-gray-200 dark:border-gray-800">
          <h3 className="text-lg font-bold text-gray-900 dark:text-white">
            Summary
          </h3>
        </div>
        <div className="p-6 text-center">
          <div className="space-y-4">
            <div className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6 text-gray-400 dark:text-gray-500" />
            </div>
            <div className="space-y-2">
              <h4 className="text-sm font-semibold text-gray-900 dark:text-white">
                No Data Available
              </h4>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                Submit some expenses to see your summary.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const totalExpenses = expenses.length;
  const approvedExpenses = expenses.filter(e => e.status === 'approved').length;
  const pendingExpenses = expenses.filter(e => e.status === 'pending').length;
  const totalAmount = expenses.reduce((sum, expense) => sum + parseFloat(expense.amount), 0);

  return (
    <div className="bg-white dark:bg-[#1E1E1E] rounded-lg border border-gray-200 dark:border-gray-800 overflow-hidden">
      <div className="bg-gray-100 dark:bg-[#262626] px-6 py-4 border-b border-gray-200 dark:border-gray-800">
        <h3 className="text-lg font-bold text-gray-900 dark:text-white">
          Summary
        </h3>
      </div>
      <div className="p-6 space-y-5">
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-gray-500 dark:text-gray-400">
              Total Expenses
            </span>
            <span className="font-semibold text-gray-900 dark:text-white">
              {totalExpenses}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500 dark:text-gray-400">
              Approved
            </span>
            <span className="font-semibold text-green-600 dark:text-green-400">
              {approvedExpenses}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500 dark:text-gray-400">
              Pending
            </span>
            <span className="font-semibold text-yellow-600 dark:text-yellow-400">
              {pendingExpenses}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-500 dark:text-gray-400">
              Total Amount
            </span>
            <span className="font-semibold text-gray-900 dark:text-white">
              ${totalAmount.toFixed(2)}
            </span>
          </div>
        </div>
        <div className="border-t border-gray-200 dark:border-gray-800"></div>
        <div className="text-center">
          <button className="inline-flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 active:text-blue-900 dark:active:text-blue-200 font-semibold transition-colors duration-150">
            <span>Export CSV</span>
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default function ExpensesList() {
  const [searchTerm, setSearchTerm] = useState("");
  const [expenses, setExpenses] = useState([]);
  const [filteredExpenses, setFilteredExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Load expenses
  useEffect(() => {
    const loadExpenses = async () => {
      try {
        setLoading(true);
        const response = await fetch('/api/expenses');
        const data = await response.json();
        
        if (!response.ok) {
          throw new Error(data.error || 'Failed to load expenses');
        }

        setExpenses(data.expenses || []);
        setFilteredExpenses(data.expenses || []);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    loadExpenses();
  }, []);

  const handleSearch = (e) => {
    const term = e.target.value.toLowerCase();
    setSearchTerm(term);

    if (term === "") {
      setFilteredExpenses(expenses);
    } else {
      const filtered = expenses.filter(
        (expense) =>
          expense.description.toLowerCase().includes(term) ||
          expense.category_name?.toLowerCase().includes(term) ||
          expense.employee_name?.toLowerCase().includes(term) ||
          expense.status.toLowerCase().includes(term) ||
          expense.amount.toString().includes(term)
      );
      setFilteredExpenses(filtered);
    }
  };

  const handleRowClick = (expense) => {
    console.log("Expense clicked:", expense);
    // TODO: Open expense detail modal
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 rounded w-1/4"></div>
          <div className="h-64 bg-gray-200 dark:bg-gray-700 rounded"></div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-lg p-4">
          <h3 className="text-lg font-semibold text-red-800 dark:text-red-200">Error</h3>
          <p className="text-red-600 dark:text-red-300">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col space-y-4 lg:flex-row lg:items-center lg:justify-between lg:space-y-0">
        <h2 className="text-xl lg:text-2xl font-bold text-gray-900 dark:text-white">
          Expenses
        </h2>

        <div className="flex flex-col space-y-3 sm:flex-row sm:items-center sm:space-y-0 sm:space-x-4">
          {/* Search */}
          <div className="relative flex-1 lg:flex-initial">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400 dark:text-gray-500" />
            </div>
            <input
              type="text"
              className="block w-full lg:w-64 pl-10 pr-4 py-2.5 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-[#262626] placeholder-gray-500 dark:placeholder-gray-400 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 focus:border-transparent transition-colors duration-150"
              placeholder="Search Expenses"
              value={searchTerm}
              onChange={handleSearch}
            />
          </div>

          {/* Filter and Export buttons */}
          <div className="flex space-x-3">
            <button className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-[#262626] text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-400 dark:hover:border-gray-600 active:bg-gray-100 dark:active:bg-gray-700 active:border-gray-500 dark:active:border-gray-500 transition-colors duration-150">
              <Filter className="w-4 h-4" />
              <span className="hidden sm:inline">Filters</span>
            </button>

            <button className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-[#262626] text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-800 hover:border-gray-400 dark:hover:border-gray-600 active:bg-gray-100 dark:active:bg-gray-700 active:border-gray-500 dark:active:border-gray-500 transition-colors duration-150">
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Export</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="space-y-6 xl:space-y-0 xl:grid xl:grid-cols-4 xl:gap-6">
        {/* Expenses Table */}
        <div className="xl:col-span-3">
          <ExpensesTable
            expenses={filteredExpenses}
            onRowClick={handleRowClick}
          />
        </div>

        {/* Summary Card */}
        <div className="xl:col-span-1">
          <SummaryCard expenses={filteredExpenses} />
        </div>
      </div>
    </div>
  );
}
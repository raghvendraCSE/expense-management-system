import {
  Search,
  LayoutGrid,
  Receipt,
  CheckCircle,
  BarChart2,
  Users,
  Settings,
  LogOut,
  ChevronRight,
  BadgeCheck,
  X,
} from "lucide-react";
import useUser from "@/utils/useUser";
import { useState, useEffect } from "react";

export default function Sidebar({ onClose, currentTab, onTabChange }) {
  const { data: user, loading } = useUser();
  const [userProfile, setUserProfile] = useState(null);

  useEffect(() => {
    if (user?.id) {
      fetch('/api/user-profile')
        .then(res => res.json())
        .then(data => {
          if (!data.error) {
            setUserProfile(data);
          }
        })
        .catch(console.error);
    }
  }, [user]);

  const workplaceNavItems = [
    { 
      icon: LayoutGrid, 
      label: "Dashboard", 
      id: "dashboard", 
      active: currentTab === "dashboard" 
    },
    { 
      icon: Receipt, 
      label: "Expenses", 
      id: "expenses", 
      active: currentTab === "expenses" 
    },
    { 
      icon: CheckCircle, 
      label: "Approvals", 
      id: "approvals", 
      active: currentTab === "approvals",
      roles: ['admin', 'manager']
    },
    { 
      icon: BarChart2, 
      label: "Reports", 
      id: "reports", 
      active: currentTab === "reports",
      roles: ['admin', 'manager']
    },
    { 
      icon: Users, 
      label: "Team Management", 
      id: "users", 
      active: currentTab === "users",
      roles: ['admin']
    },
    { 
      icon: Settings, 
      label: "Settings", 
      id: "settings", 
      active: currentTab === "settings",
      roles: ['admin']
    },
  ];

  const filteredWorkplaceItems = workplaceNavItems.filter(item => 
    !item.roles || item.roles.includes(userProfile?.role)
  );

  const handleSignOut = () => {
    window.location.href = '/account/logout';
  };

  if (loading) {
    return (
      <div className="w-64 bg-white dark:bg-[#1E1E1E] border-r border-gray-200 dark:border-gray-800 flex flex-col h-full">
        <div className="p-4">
          <div className="animate-pulse h-8 w-32 bg-gray-200 dark:bg-gray-700 rounded mb-4"></div>
          <div className="animate-pulse h-10 w-full bg-gray-200 dark:bg-gray-700 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-64 bg-white dark:bg-[#1E1E1E] border-r border-gray-200 dark:border-gray-800 flex flex-col h-full">
      {/* Mobile close button */}
      <div className="lg:hidden flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800">
        <div className="flex items-center">
          <div className="w-8 h-8 bg-[#18B84E] dark:bg-[#16A249] rounded flex items-center justify-center">
            <span className="text-white font-bold text-sm">EM</span>
          </div>
          <div className="ml-2 flex items-center">
            <span className="text-[#111111] dark:text-white font-medium text-lg">
              Expense
            </span>
            <span className="text-[#18B84E] dark:text-[#16A249] font-medium text-lg">
              Manager
            </span>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 rounded-md text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 active:bg-gray-200 dark:active:bg-gray-700 transition-colors duration-150"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Search Section */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-800">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-gray-400 dark:text-gray-500" />
          </div>
          <input
            type="text"
            className="block w-full pl-10 pr-16 py-2.5 border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-[#262626] placeholder-gray-400 dark:placeholder-gray-500 text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-[#18B84E] dark:focus:ring-[#16A249] focus:border-transparent text-sm transition-colors duration-150"
            placeholder="Search"
          />
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
            <kbd className="px-2 py-1 text-xs font-semibold text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-700 border border-gray-200 dark:border-gray-600 rounded">
              ⌘F
            </kbd>
          </div>
        </div>
      </div>

      {/* Navigation Items - Scrollable */}
      <div className="flex-1 overflow-y-auto py-4">
        {/* WORKPLACE Section */}
        <div className="px-4 mb-6">
          <h3 className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">
            WORKPLACE
          </h3>
          <nav className="space-y-1">
            {filteredWorkplaceItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <button
                  key={index}
                  onClick={() => onTabChange?.(item.id)}
                  className={`
                    group flex items-center w-full px-3 py-2.5 text-sm font-medium rounded-md transition-colors duration-150
                    ${
                      item.active
                        ? "bg-white dark:bg-[#262626] text-gray-900 dark:text-white border border-gray-200 dark:border-gray-700 shadow-sm dark:shadow-none"
                        : "text-gray-600 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-gray-200 active:bg-gray-100 dark:active:bg-gray-700"
                    }
                  `}
                >
                  <Icon
                    className={`
                    flex-shrink-0 -ml-1 mr-3 h-5 w-5 transition-colors duration-150
                    ${item.active ? "text-gray-900 dark:text-white" : "text-gray-400 dark:text-gray-500 group-hover:text-[#18B84E] dark:group-hover:text-[#16A249] group-active:text-[#16A249] dark:group-active:text-[#14D45D]"}
                  `}
                  />
                  <span className="flex-1 text-left">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Logout */}
        <div className="px-4">
          <button
            onClick={handleSignOut}
            className="group flex items-center w-full px-3 py-2.5 text-sm font-medium text-red-600 dark:text-red-400 rounded-md hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-700 dark:hover:text-red-300 active:bg-red-100 dark:active:bg-red-900/30 active:text-red-800 dark:active:text-red-200 transition-colors duration-150"
          >
            <LogOut className="flex-shrink-0 -ml-1 mr-3 h-5 w-5 text-red-500 dark:text-red-400 group-hover:text-red-600 dark:group-hover:text-red-300 group-active:text-red-700 dark:group-active:text-red-200 transition-colors duration-150" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* User Profile Card - Bottom */}
      {userProfile && (
        <div className="border-t border-gray-200 dark:border-gray-800 p-4">
          <div className="w-full flex items-center p-2 rounded-lg">
            <div className="relative flex-shrink-0">
              <div className="h-10 w-10 rounded-full bg-[#18B84E] dark:bg-[#16A249] flex items-center justify-center">
                <span className="text-white font-semibold text-sm">
                  {userProfile.user_name ? userProfile.user_name.charAt(0).toUpperCase() : 'U'}
                </span>
              </div>
              <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 bg-[#18B84E] dark:bg-[#16A249] border-2 border-white dark:border-[#1E1E1E] rounded-full"></div>
            </div>

            <div className="ml-3 flex-1 flex flex-col justify-center">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">
                  {userProfile.user_name || 'User'}
                </p>
              </div>
              <div className="flex items-center mt-0.5">
                <div className="flex items-center px-1.5 py-0.5 bg-green-50 dark:bg-green-900/30 rounded text-xs">
                  <BadgeCheck className="h-2.5 w-2.5 text-[#18B84E] dark:text-[#16A249] mr-1" />
                  <span className="font-semibold text-[#18B84E] dark:text-[#16A249] text-xs capitalize">
                    {userProfile.role}
                  </span>
                </div>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 truncate mt-1">
                {userProfile.company_name}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}